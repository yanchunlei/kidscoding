import UIKit

class MyImagePickerController: UIImagePickerController {
  override func preferredStatusBarStyle() -> UIStatusBarStyle {
    return .LightContent
  }
}
