class SearchResult {
  var name = ""
  var artistName = ""
}
