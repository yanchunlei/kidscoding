import UIKit

class AboutViewController: UIViewController {
  
  @IBAction func close() {
    dismissViewControllerAnimated(true, completion: nil)
  }
}
