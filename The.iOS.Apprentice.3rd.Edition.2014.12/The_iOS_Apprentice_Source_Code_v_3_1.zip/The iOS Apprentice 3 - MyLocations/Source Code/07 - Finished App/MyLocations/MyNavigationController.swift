import UIKit

class MyNavigationController: UINavigationController {
  override func preferredStatusBarStyle() -> UIStatusBarStyle {
    return .LightContent
  }
}
