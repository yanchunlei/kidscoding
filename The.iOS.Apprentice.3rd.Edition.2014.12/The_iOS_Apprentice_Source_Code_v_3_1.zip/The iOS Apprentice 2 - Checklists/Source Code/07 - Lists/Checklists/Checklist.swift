//
//  Checklist.swift
//  Checklists
//
//  Created by M.I. Hollemans on 18/09/14.
//  Copyright (c) 2014 Razeware. All rights reserved.
//

import UIKit

class Checklist: NSObject {
  var name = ""

  init(name: String) {
    self.name = name
    super.init()
  }
}
